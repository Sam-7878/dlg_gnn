# DLG-StreamMC SCI Round 3 데이터 재구축·실험 완결 작업지시서

> **대상 상태**  
> `DLG_StreamMC_SCI_Round2_Development_Experiment_Report`
>
> **현재 판정**  
> `NOT_READY` / Paper Revision Gate `CLOSED`
>
> **Round 3의 목적**  
> 기존 legacy processed graph artifact의 timestamp·normalizer·relation·KNN provenance 부재를 해결하기 위해 raw transaction에서 SCI용 processed dataset을 다시 생성하고, 그 위에서 실제 PyGOD·DLG-GNN·DLG-StreamMC 실험을 끝까지 수행한다.
>
> **중요 판단**  
> 현재 문제는 StreamMC의 핵심 소프트웨어 구조가 부족해서가 아니라, **기존 processed dataset이 temporal provenance를 보존하지 않아 SCI용 chronological/streaming 평가의 유효성을 입증할 수 없다는 것**이다. 따라서 Round 3는 대규모 모델 기능 추가보다 데이터 재구축과 paper-eligible experiment 실행에 집중한다.
>
> **기준 저장소**  
> `/mnt/d/_Work/goat_bank/dlg_gnn`
>
> **원시 transaction root**  
> `/mnt/d/_Work/_data/dataset/transactions`
>
> **새 SCI processed root**  
> `/mnt/d/_Work/_data/GoG_sci_v2`
>
> **기존 processed root**  
> `/mnt/d/_Work/_data/GoG` — legacy comparison용으로만 보존하고 main temporal experiment에는 사용하지 않는다.
>
> **최종 목표**
>
> - sample-level leakage audit `PASS`
> - paper-eligible main experiment 생성
> - Paper Revision Gate 최소 `OPEN_WITH_RESTRICTIONS`
> - quantitative manuscript revision 착수 가능 상태 확보

---

# 1. Round 2 검증 결과

## 1.1 완료된 부분

다음 기반은 완료된 것으로 인정한다.

- 3-chain full raw manifest
- fixed holdout 및 rolling-origin split artifact
- dependency lock
- clean tagged experiment code evidence
- in-scope test 통과
- stateful stream, routing, cache, queue, checkpoint 구현
- profiler 구현 및 evidence infrastructure
- hard-coded demonstration metrics의 paper 사용 차단
- smoke path 실행
- calibration/statistics utility 구현
- versioned SCI configs

## 1.2 미완료 핵심

다음은 아직 존재하지 않는다.

- leakage-safe processed dataset
- real PyGOD result
- DLG-GNN 5-seed result
- DLG-StreamMC main result
- MC sensitivity
- routing/workload result
- calibration result
- 100k-event resource result
- rolling temporal result
- held-out cross-chain result
- statistical comparison

## 1.3 raw timestamp ordering violation 해석

Ethereum 87개, BSC 157개, Polygon 114개 contract CSV에서 row timestamp가 단조 증가하지 않았다.

이는 곧바로 미래 정보 누수를 의미하지는 않는다. 원본 CSV가 단순히 정렬되지 않았을 수 있다. 그러나 다음 조건을 충족하지 않으면 streaming replay에 사용할 수 없다.

1. 각 row에 신뢰 가능한 timestamp가 존재한다.
2. timestamp, block number, transaction index를 기준으로 deterministic stable sort한다.
3. 정렬 전후 row multiset hash가 동일하다.
4. 중복 transaction의 처리 규칙을 기록한다.
5. processed feature가 event cutoff 이후 정보를 사용하지 않는다.

Round 3에서는 원본을 수정하지 않고 정렬된 immutable SCI intermediate artifact를 별도로 생성한다.

---

# 2. Round 3 범위

## 포함

- raw-to-processed mapping 복원
- transaction sorting
- contract ID 보존
- feature provenance 보존
- timestamp-safe graph generation
- train-only normalizer
- incremental relation/KNN construction
- leakage audit
- legacy-vs-v2 data comparison
- real baseline and main experiments
- all required SCI evaluations
- Round 3 verification report

## 제외

- 완전히 새로운 GNN architecture 개발
- TGN으로 전체 교체
- production RPC ingestion
- analyst UI
- raw source label 자체의 재수집

---

# 3. SCI Dataset v2 설계

## 3.1 디렉토리 구조

```text
/mnt/d/_Work/_data/GoG_sci_v2/
├── manifests/
├── labels/
├── sorted_transactions/
│   ├── ethereum/
│   ├── bsc/
│   └── polygon/
├── graphs/
│   ├── ethereum/
│   ├── bsc/
│   └── polygon/
├── features/
├── mappings/
├── splits/
├── normalizers/
├── relations/
├── audit/
└── DATASET_CARD.md
```

---

## 3.2 Sample Identity

numeric graph filename 사용을 중단한다.

모든 graph는 다음을 갖는다.

```python
sample_id: str
contract_id: str
chain_id: str
graph_version: str
source_file: str
source_sha256: str
label: int
label_category: int
event_start: int
event_end: int
cutoff_time: int
num_nodes: int
num_edges: int
```

권장 filename:

```text
{chain}__{contract_address}__{cutoff_time}.pt
```

contract full-history graph는:

```text
{chain}__{contract_address}__full.pt
```

로 구분하되 chronological main evaluation에는 full future graph를 사용하지 않는다.

---

## 3.3 Sorted Transaction Artifact

각 raw CSV에 대해 다음 정렬키를 사용한다.

```text
timestamp
block_number
transaction_index
transaction_hash
original_row_index
```

필드가 없는 경우 사용 가능한 subset과 tie-break rule을 manifest에 기록한다.

각 sorted file metadata:

```json
{
  "source_path": "...",
  "source_sha256": "...",
  "sorted_path": "...",
  "sorted_sha256": "...",
  "row_count_before": 0,
  "row_count_after": 0,
  "row_multiset_hash_before": "...",
  "row_multiset_hash_after": "...",
  "was_reordered": true,
  "duplicate_rows": 0,
  "duplicate_transactions": 0,
  "sort_keys": [],
  "timestamp_min": 0,
  "timestamp_max": 0
}
```

### 완료 조건

- row count 보존
- row multiset hash 보존
- timestamp 단조 증가
- 재실행 시 동일 hash
- 원본 파일은 변경하지 않음

---

# 4. Timestamp-Safe Graph 생성

## 4.1 두 가지 graph mode 분리

### Static Compatibility Mode

기존 DLG-GNN/GoG와 비교하기 위한 full-history graph.

- 기존 benchmark 재현 목적
- temporal claim에 사용 금지
- `paper_scope=static_compatibility`

### Temporal Streaming Mode

prediction cutoff \(t\) 이전 거래만 사용.

\[
G_i(t)=\{e\in E_i \mid t_e \le t\}
\]

- DLG-StreamMC main experiment
- chronological replay
- temporal robustness
- cross-chain temporal transfer
- `paper_scope=streaming_main`

두 mode 결과를 같은 표에서 혼합하지 않는다.

---

## 4.2 Window 정책

지원:

- expanding window
- sliding time window
- maximum recent edges
- maximum recent nodes

각 sample metadata에 다음을 저장한다.

```text
window_type
window_start
window_end
edge_cutoff_rule
node_sampling_rule
```

---

## 4.3 Feature Provenance

각 feature에 machine-readable 정의를 저장한다.

```json
{
  "feature_name": "in_degree",
  "source_columns": ["from", "to"],
  "aggregation": "count",
  "time_scope": "event_time <= cutoff_time",
  "fit_scope": "none",
  "version": "feature-v2.0"
}
```

금지:

- full-history lifetime
- future total amount
- future degree
- 전체 기간 frequency
- test 기간을 포함한 scaler
- future neighbor embedding

---

# 5. Label Mapping 검증

현재 binary rule:

```text
category 0 = benign
all non-zero categories = fraud
```

이 rule은 upstream GoG의 의미와 일치하는지 확인한다.

필수 작업:

1. upstream repository의 label-generation 또는 dataset 설명 파일을 식별한다.
2. local category code의 의미를 기록한다.
3. source repository commit/tag를 manifest에 기록한다.
4. upstream metadata를 찾지 못하면 `MISSING_UPSTREAM_VERSION_METADATA`를 그대로 limitation으로 유지한다.
5. positive ratio는 population prevalence가 아니라 fraud-oriented labeled corpus 비율임을 명시한다.

Polygon의 97.37% fraud 비율 때문에 다음 metric을 반드시 우선한다.

- PR-AUC
- fraud recall
- MCC
- balanced accuracy
- classwise calibration

ROC-AUC 단독 해석을 금지한다.

---

# 6. Train-Only Preprocessing

## 6.1 Normalizer

각 fold마다 train data로만 fit한다.

artifact:

```text
normalizers/{chain}/{fold}/normalizer.json
```

기록:

- train sample IDs
- train time interval
- feature means/scales
- fit hash
- code version

validation/test에서는 transform만 수행한다.

---

## 6.2 Relation Graph

relation graph는 prediction 시점에 관측 가능한 entity만 사용한다.

### Temporal relation

\[
(i,j)\in E_t \iff
t_i,t_j \le t_{\mathrm{cutoff}}
\]

### Embedding KNN

KNN candidate pool은 train 또는 현재까지 stream에 등장한 node만 포함한다.

artifact:

```json
{
  "cutoff_time": 0,
  "candidate_pool_hash": "...",
  "candidate_count": 0,
  "relation_types": [],
  "future_nodes_included": 0
}
```

### 완료 조건

- future candidate 0
- future relation 0
- fold-specific relation provenance 존재

---

# 7. Leakage Audit v2

실제 모든 paper-eligible sample에 대해 검사한다.

## 필수 항목

- sorted event monotonicity
- feature max timestamp
- graph edge max timestamp
- normalizer fit interval
- relation construction interval
- KNN candidate pool
- threshold source
- calibration source
- future lifetime feature
- train/test overlap
- duplicate sample ID

output:

```text
audit/leakage_audit_{chain}_{fold}.json
audit/leakage_violations.csv
```

### Gate

```text
PASS: violations = 0
FAIL: violations > 0
INCOMPLETE: provenance field missing
```

`PASS` 전에는 pilot/main 실행을 금지한다.

---

# 8. Legacy Dataset과 SCI v2 비교

새 dataset이 기존 결과와 지나치게 달라지는 이유를 설명하기 위해 compatibility audit를 수행한다.

chain별 비교:

- graph count
- node/edge distribution
- label distribution
- feature distribution
- full-history graph metric
- missing processed graph
- raw-to-graph mapping
- embedded label consistency

특히 현재 embedded graph label distribution과 label CSV binary mapping의 0/1 방향이 반대로 보이는 부분을 확인한다.

예:

- Ethereum CSV: fraud 8,433 / benign 6,031
- processed graph embedded labels: 0=8,367 / 1=6,018

다음 가능성을 검증한다.

1. embedded graph에서 0이 fraud이고 1이 benign
2. label orientation이 뒤집힘
3. 일부 graph가 누락되며 count 차이 발생
4. graph index와 label row mapping이 어긋남

이 문제를 해결하지 않으면 static compatibility result도 paper-eligible로 인정하지 않는다.

---

# 9. Real PyGOD Baseline 구현

현재 hard-coded demonstration metric path는 폐기하거나 명시적으로 demo 전용으로 유지한다.

## 요구사항

- 실제 PyGOD `.fit()`/`.decision_score_` 실행
- model version 기록
- best parameter source 기록
- 동일 split
- 동일 graph feature scope
- partition coverage
- runtime
- OOM/failure
- prediction row 저장

대상:

- DOMINANT
- DONE
- GAE
- AnomalyDAE
- CoLA
- CONAD
- GAAN
- GUIDE

모든 model을 full matrix로 실행하기 전에 pilot으로 실제 prediction artifact가 생성되는지 확인한다.

---

# 10. Paper-Eligible 실험 단계

## Phase A. v2 Data Smoke

각 chain 100개.

검증:

- mapping
- sorted events
- temporal graph
- feature provenance
- normalizer
- relation
- leakage audit
- trace

paper metric 생성 금지.

---

## Phase B. Pilot

각 chain 한 fold·한 seed.

- DOMINANT
- best reconstruction baseline
- DLG Full
- DLG-StreamMC
- MC T=1,8

pilot result는 exploratory.

---

## Phase C. Main 5-Seed

seeds:

```text
11, 22, 33, 44, 55
```

모델:

- all real PyGOD
- DLG L1
- DLG L1+L2
- DLG Full
- DLG Full+LPP
- StreamMC deterministic
- StreamMC dual-threshold
- StreamMC risk-sensitive

chain:

- ETH
- BSC
- Polygon
- pooled

---

## Phase D. MC Sensitivity

```text
T={1,3,5,8,10,20,30}
```

---

## Phase E. Routing/Workload

- no routing
- variance-only
- dual-threshold
- risk-sensitive

---

## Phase F. Calibration

- deterministic
- MC
- temperature-scaled MC
- selective MC

---

## Phase G. 100k Streaming/Resource

- normal
- burst
- overload
- cache pressure
- checkpoint/restart
- delayed
- out-of-order
- 100k long-run

---

## Phase H. Temporal Robustness

rolling-origin 5 folds.

---

## Phase I. Cross-Chain

held-out chain matrix.

---

## Phase J. Statistics

- paired bootstrap
- CI
- DeLong or justified alternative
- Wilcoxon
- Friedman/Nemenyi
- Holm correction
- effect size

---

# 11. Git·Artifact Freeze

Round 2 report에서 현재 working tree가 다시 dirty로 나타난다. Round 3 main experiment 전 다음을 수행한다.

1. generated reports/results는 repository tracked source와 분리한다.
2. `.gitignore` 규칙 정리
3. source/config/test 변경 commit
4. tag 생성

```bash
git tag -a dlg-streammc-sci-v2.0 -m "Leakage-safe SCI dataset and experiment pipeline"
```

5. strict orchestrator가 main 실행 시 dirty tree를 거부하도록 유지한다.
6. report 생성 후 dirty가 되는 것은 허용하되, run manifest에는 실행 시작 시 clean 상태를 기록한다.

---

# 12. 새 결과 Schema 필수 열

기존 schema에 다음을 추가한다.

```text
dataset_mode
dataset_version
raw_manifest_hash
processed_manifest_hash
mapping_version
feature_version
feature_provenance_hash
normalizer_hash
relation_state_hash
candidate_pool_hash
cutoff_time
window_type
leakage_audit_hash
paper_eligible
paper_scope
```

`paper_eligible=true`는 validator만 설정한다.

---

# 13. 검증 보고서 Round 3

최종 산출물:

```text
DLG_StreamMC_SCI_Round3_Verification_Report.md
DLG_StreamMC_SCI_Round3_Verification_Report.json
DLG_StreamMC_SCI_Round3_Evidence_Index.csv
DLG_StreamMC_SCI_Round3_Validation.json
DLG_StreamMC_SCI_Round3_Evidence_Package.zip
```

보고서 첫 화면:

```text
Processed Dataset v2: PASS
Raw-to-Graph Mapping: PASS
Embedded Label Orientation: PASS
Sample-Level Leakage: PASS
Paper-Eligible Experiments: N
Main Baseline: PASS
MC Sensitivity: PASS
Calibration: PASS
100k Streaming: PASS
Temporal: PASS
Cross-Chain: PASS
Statistics: PASS
Paper Revision Gate: OPEN / OPEN_WITH_RESTRICTIONS
```

---

# 14. 논문 수정 착수 조건

다음이 모두 충족될 때 논문 정량 수정에 들어간다.

- [ ] SCI dataset v2 생성
- [ ] raw-to-graph mapping complete
- [ ] embedded label orientation 해결
- [ ] upstream label semantics 문서화 또는 limitation 확정
- [ ] leakage audit PASS
- [ ] actual PyGOD predictions 존재
- [ ] DLG/StreamMC 5-seed main result 존재
- [ ] MC sensitivity 완료
- [ ] routing/workload 완료
- [ ] calibration 완료
- [ ] 100k resource 완료
- [ ] temporal 완료
- [ ] cross-chain 완료
- [ ] statistics 완료
- [ ] unresolved CRITICAL 0
- [ ] Paper Revision Gate 최소 OPEN_WITH_RESTRICTIONS

---

# 15. 우선순위와 중단 조건

## P0

1. graph label orientation 확인
2. raw-to-graph mapping 구현
3. sorted transaction artifact
4. temporal graph builder
5. feature provenance
6. leakage audit PASS

## P1

7. real PyGOD pilot
8. DLG/StreamMC pilot
9. main 5-seed

## P2

10. MC/routing/calibration
11. 100k resource
12. temporal/cross-chain
13. statistics

## 중단 조건

다음 중 하나면 main experiment를 중단한다.

- graph label orientation 불명
- raw-to-graph mapping 불완전
- leakage audit FAIL/INCOMPLETE
- split hash mismatch
- normalizer train-only 보장 실패
- actual baseline이 demo metric path를 사용
- dirty Git at run start
- sample count mismatch

---

# 16. 최종 AI Agent 지시

1. 기존 processed graph를 억지로 temporal-safe라고 해석하지 말라.
2. raw CSV의 비정렬은 원본 수정이 아니라 immutable sorted artifact로 해결하라.
3. sorted row multiset 보존을 hash로 증명하라.
4. graph에 contract ID와 source provenance를 직접 저장하라.
5. embedded label orientation 문제를 가장 먼저 해결하라.
6. full-history graph와 temporal graph를 명확히 분리하라.
7. 모든 feature가 cutoff 이전 정보만 사용하도록 하라.
8. train-only normalizer와 historical candidate pool을 강제하라.
9. leakage audit가 PASS하기 전 model experiment를 실행하지 말라.
10. 실제 PyGOD inference 결과만 paper-eligible로 인정하라.
11. pilot과 main 결과를 혼합하지 말라.
12. 모든 단계가 끝나면 Round 3 verification report를 생성하라.

---

# 17. 예상 최종 명령

## Dataset v2 생성

```bash
python scripts/build_sci_dataset_v2.py \
  --raw-root /mnt/d/_Work/_data/dataset/transactions \
  --legacy-root /mnt/d/_Work/_data/GoG \
  --output-root /mnt/d/_Work/_data/GoG_sci_v2 \
  --chains ethereum bsc polygon \
  --strict
```

## Leakage audit

```bash
python scripts/audit_sci_dataset_v2.py \
  --dataset-root /mnt/d/_Work/_data/GoG_sci_v2 \
  --all-folds \
  --strict
```

## Main experiment

```bash
python -m gog_fraud.pipelines.run_sci_evaluation \
  --config configs/sci_v2/experiments/main.yaml \
  --dataset-root /mnt/d/_Work/_data/GoG_sci_v2 \
  --output-root results_sci_v2 \
  --require-clean-git \
  --require-leakage-pass \
  --strict
```

## Verification report

```bash
python scripts/build_round3_verification_report.py \
  --repo-root /mnt/d/_Work/goat_bank/dlg_gnn \
  --dataset-root /mnt/d/_Work/_data/GoG_sci_v2 \
  --results-root results_sci_v2 \
  --output reports/DLG_StreamMC_SCI_Round3_Verification_Report.md \
  --strict
```
