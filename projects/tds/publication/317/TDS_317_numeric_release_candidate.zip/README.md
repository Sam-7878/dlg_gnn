# TDS317 numerical evidence — local release candidate

Run `python replay.py` with NumPy, pandas, SciPy and scikit-learn. This checks all
110 score arrays and 95 validation-only calibrators without manuscripts, weights
or upstream raw data. The arrays consist of 65 preserved original results and
45 new fits; distinct original and first+7d cohorts must not be paired.

This is not an approved public release. No TDS immutable tag or anonymous download
has been verified. Identifier reduction is not a formal anonymization guarantee.
Upstream GoG terms, including CC BY-NC-SA 4.0, continue to apply to relevant
derivatives. No claim of unrestricted MIT licensing for these data is made.
Raw transactions, contract mappings, model weights, author records, and private
manuscript/source ZIPs are excluded. Codebase: https://github.com/Sam-7878/dlg_gnn

`source/` supplies reconstruction/training helpers and tests in repository layout.
Full reconstruction still needs raw data and the documented training environment.
The old18 unit regressions run cold with PyTorch/PyG installed; the new317 integration
tests require the author-local full artifacts and are run in the original checkout.
