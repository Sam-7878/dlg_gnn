# Rights separation — not publication authorization

Repository software follows the applicable repository/third-party code licenses.
Numerical predictions, source-derived lineage and graph/data derivatives are not
automatically MIT-licensed by inclusion beside code. Upstream GoG data retain their
original access and CC BY-NC-SA4.0 terms. Derivative redistribution has not received
the required author/rights approval. This local candidate must not be advertised
as an unrestricted approved public release. Raw data, protected contract mappings,
model weights, paper sources and private author records are excluded.
