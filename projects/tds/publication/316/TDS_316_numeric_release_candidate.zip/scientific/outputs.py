"""Numeric operating-budget helper extracted from R314; manuscript writer excluded."""
import math
import numpy as np

def operating(labels,scores):
    # Stable event order resolves score ties, with no label-aware tie-break.
    order=np.argsort(-scores,kind='stable'); ranked=labels[order];positive=int(labels.sum())
    out={}
    for name,k in [('top_1pct',math.ceil(.01*len(labels))),('top_5pct',math.ceil(.05*len(labels))),('top_50',50),('top_100',100)]:
        hit=int(ranked[:k].sum());out.update({f'{name}_budget':k,f'{name}_captured':hit,f'{name}_precision':hit/k,f'{name}_recall':hit/positive})
    return out
