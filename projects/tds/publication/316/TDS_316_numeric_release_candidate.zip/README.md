# TDS 316 numeric candidate — unpublished

This local candidate accompanies the publication-only R316 revision. All65 test
score/label arrays are byte-identical to both the originally reviewed R315 numeric
candidate and the current relocated R315 candidate. No new training or scoring
was performed. The R316 manuscript describes supervised retrospective financial
graph risk screening, not unsupervised discovery or prospective deployment.

Extract this ZIP into an empty folder and run:

```bash
python replay.py . --statistics
python -m pytest tests -q
```

Replay verifies the manifest, aligned3648/107 panels, seven supplemental AP mean/SD
pairs and all three10000-replicate protocols for one original comparison. Scientific
and publication-gate tests require PyTorch/PyG in addition to the CPU replay stack.
Exact environment versions and the R315 detailed reproduction guide are included.

Reproduction levels: L0 private author manuscript builds; L1 author-local processed
artifact hashes; L2 locally verified numeric/statistical replay, with anonymous
public release still pending; L3 full independent retraining not guaranteed.
RTX3090 capacity does not retroactively reproduce frozen experiments.

Manuscripts, publisher class/styles/logos, raw transaction data, contract addresses,
checkpoints and private author records are excluded. Raw third-party data remain
under GoG CC BY-NC-SA4.0. Software, numerical derivatives and the prospective
manuscript's publication license are separate rights categories. No blanket CC BY
relicensing or rights approval is inferred. Read the included upstream license and
redistribution review; author approval is required before public deposition.

The shared repository is https://github.com/Sam-7878/dlg_gnn. Current TDS results
are under projects/tds/results/<task>. This package is local, with no verified
TDS immutable tag/release URL or DOI. A Git commit is not public-release proof.
